package second;



import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapreduce.Partitioner;

public  class mypat2{}/* extends Partitioner<Text,Text>
{

	@Override
	public int getPartition(Text arg0, Text arg1,int args2) {

String val=arg0.toString();
if(val.equals("[ERROR]"))
{
		return 0;
	}
else if(val.equals("[DEBUG]"))
{
	return 1;
}
else if(val.equals("[TRACE]"))
{
	return 2;
}
else 
{
	return 3;
}
	}

}

*/
