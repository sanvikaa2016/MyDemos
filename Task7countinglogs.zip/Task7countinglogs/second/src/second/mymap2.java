package second;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap2 extends Mapper<LongWritable,Text,Text,IntWritable> {

public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
	
	String line=inpv.toString();
	String s[]=line.split(" ");
	
	String s1=s[3];
	c.write(new Text(s1+" ---"),new IntWritable(1));
	
}
	
	
}
