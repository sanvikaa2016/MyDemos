package second;

public class myred2 {

}
