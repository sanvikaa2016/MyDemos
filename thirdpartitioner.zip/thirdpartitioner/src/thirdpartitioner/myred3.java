package thirdpartitioner;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myred3  extends Reducer<Text,IntWritable,Text,IntWritable>{
	public void reduce(Text inpk,IntWritable inpv,Context c   ) throws IOException, InterruptedException
	{
		
		c.write(inpk ,inpv);
	}

}