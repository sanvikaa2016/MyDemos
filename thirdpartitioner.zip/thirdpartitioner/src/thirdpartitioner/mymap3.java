package thirdpartitioner;


import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap3 extends Mapper<LongWritable, Text,Text,IntWritable> {
	public void map(LongWritable inpk, Text inpv,Context c) throws IOException, InterruptedException
	{
		String value=inpv.toString();
		String eachval[]=value.split(",");
		int no=Integer.parseInt(eachval[1]);
		//Text outk=new Text(eachval[0]);
if(no>70){
	//	IntWritable outv=new IntWritable(no);
		c.write(new Text(eachval[0]),new IntWritable(no));
}
		
		
	}

}
