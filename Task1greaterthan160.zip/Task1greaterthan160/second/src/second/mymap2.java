package second;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap2 extends Mapper<LongWritable, Text,Text,DoubleWritable> {
	public void map(LongWritable inpk, Text inpv,Context c) throws IOException, InterruptedException
	{
		String value=inpv.toString();
		String eachval[]=value.split(",");
		//int no=Integer.parseInt(eachval[3]);
		double no= Double.parseDouble(eachval[3]);
		//Text outk=new Text(eachval[0]);
if(no>160){
	//	IntWritable outv=new IntWritable(no);
	String data1=" ";
for(int i=0;i<eachval.length;i++)
	{
	data1=data1+eachval[i]+" \t";
	}
		c.write(new Text(data1),new DoubleWritable(no));
//}
		}
		
		
	}

}
