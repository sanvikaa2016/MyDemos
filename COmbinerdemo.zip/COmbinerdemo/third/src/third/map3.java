package third;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class map3 extends Mapper<LongWritable,Text, Text,Text > {
	public void map(LongWritable inpK, Text inpV, Context c) throws IOException, InterruptedException{
	
		String Value = inpV.toString();
		String eachVal[]= Value.split(" ");
		c.write(new Text(eachVal[0]), new Text(eachVal[1]));
	
	}

}
