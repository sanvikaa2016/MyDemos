package second;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myred2  extends Reducer<Text,DoubleWritable,Text,DoubleWritable>{
	public void reduce(Text inpk,Iterable<DoubleWritable> inpv,Context c   ) throws IOException, InterruptedException
	{
		
        int count=0;
		for(DoubleWritable ii:inpv)
		{
			
		count++;
			
		}
		c.write(new Text(),new DoubleWritable(count));
	
	}

}
