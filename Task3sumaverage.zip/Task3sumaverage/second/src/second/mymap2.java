package second;

import java.io.IOException;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap2 extends Mapper<LongWritable,Text,IntWritable,DoubleWritable>{
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		String value=inpv.toString();
		String eachval[]=value.split(",");
		double amt=Double.parseDouble(eachval[3]);
		int uid= Integer.parseInt(eachval[2]);

		
		c.write(new IntWritable(uid),new DoubleWritable(amt));
		}
	}

