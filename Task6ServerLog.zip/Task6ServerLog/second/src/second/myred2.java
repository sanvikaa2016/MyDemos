package second;


import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class myred2 extends Reducer<Text,Text,Text,Text>{

	public void reduce(Text inpk,Text inpv,Context c   ) throws IOException, InterruptedException 
	{
		
		c.write(inpk,inpv);
}
}