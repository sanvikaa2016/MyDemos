package second;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap2 extends Mapper<LongWritable,Text,Text,Text>{
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{

String value=inpv.toString();
		String eachval[]=value.split(" ");
		

String s=String.valueOf(eachval[3]);


		c.write(new  Text(s),new Text(value));
		}
	}

