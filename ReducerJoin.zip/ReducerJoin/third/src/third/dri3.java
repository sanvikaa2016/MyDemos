package third;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class dri3{

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Job j = new Job(new Configuration(),"Reduce Side Join");
		j.setJarByClass(dri3.class);
		j.setReducerClass(red3.class);
		j.setNumReduceTasks(1);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(Text.class);
		
		MultipleInputs.addInputPath(j, new Path(args[0]), TextInputFormat.class, map3.class);
		MultipleInputs.addInputPath(j, new Path(args[1]), TextInputFormat.class, map4.class); 
		
		FileOutputFormat.setOutputPath(j, new Path(args[2]));
		
		System.exit(j.waitForCompletion(true)?0:1);
	}

}
