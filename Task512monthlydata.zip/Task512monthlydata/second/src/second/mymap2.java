package second;

import java.io.IOException;
import java.util.Date;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap2 extends Mapper<LongWritable,Text,IntWritable,Text>{
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		String value=inpv.toString();
		String eachval[]=value.split(",");
		

String s=String.valueOf(eachval[1]);

String s1[]=s.split("-");
int mon=Integer.parseInt(s1[0]);
String data1=" ";


for(int i=0;i<eachval.length;i++)
	{
	data1=data1+eachval[i]+" \t";
	}
		c.write(new  IntWritable(mon),new Text(data1));
		}
	}

