package aaa;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap1 extends Mapper<LongWritable, Text,Text,IntWritable> {
	public void map(LongWritable inpk, Text inpv,Context c) throws IOException, InterruptedException
	{
		String value=inpv.toString();
		String eachval[]=value.split(" ");
		Text outk=new Text(eachval[0]);
		IntWritable outv=new IntWritable(1);
		c.write(outk, outv);
		
		
		
	}

}
