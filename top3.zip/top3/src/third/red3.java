package third;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class red3 extends Reducer<Text, Text, NullWritable, Text>{
	HashMap<String, Integer> hm = new HashMap<>();
	HashMap<Integer,String> hm2= new HashMap<>();
	int count =0;
	public void reduce(Text rInpKey, Iterable<Text> rInpVal, Context c) throws IOException, InterruptedException{
		
		
		for(Text each: rInpVal){
			String eachStr=each.toString();
			String[] eachWithInStr= eachStr.split(" ");
			hm.put(eachWithInStr[2], ++count);
			
		}
			for(Map.Entry m: hm.entrySet()){
				Integer key= (Integer) m.getValue();
				hm2.put(key, (String)m.getKey());
			}
			}
		
		public void cleanup(Context c) throws IOException, InterruptedException{
			
			Text rOutVal=null;
			String s1="",s3="";
			String[] s2=new String[10];
			Map.Entry<Integer,String> entry=hm2.entrySet().iterator().next();
			 Integer key= entry.getKey();
			 String value=entry.getValue();
Set<Integer> kk=hm2.keySet();

			 for(Integer each:kk)
			 {
					
			s1 =s1+":" +hm2.get(each);
				
				}
			 s2=s1.split(":");
			 for(int i=0;i<4;i++)
			 {
				 s3=s3+"\t"+s2[i];
			 }
		
			// Text rOutVal= new Text("Module " +value+" has maximum error log of " +key);
			
			 
			 c.write(null, new Text(s3));
			
		}
		}
