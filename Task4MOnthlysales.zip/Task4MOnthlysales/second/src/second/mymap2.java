package second;

import java.io.IOException;
import java.util.Date;
import java.util.StringTokenizer;
import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mymap2 extends Mapper<LongWritable,Text,IntWritable,DoubleWritable>{
	
	public void map(LongWritable inpk,Text inpv,Context c) throws IOException, InterruptedException{
		String value=inpv.toString();
		String eachval[]=value.split(",");
		
		double amt=Double.parseDouble(eachval[3]);
String s=String.valueOf(eachval[1]);
String s1[]=s.split("-");
int mon=Integer.parseInt(s1[0]);
		c.write(new IntWritable(mon),new DoubleWritable(amt));
		}
	}

