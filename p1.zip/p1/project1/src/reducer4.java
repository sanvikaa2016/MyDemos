
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class reducer4 extends Reducer<IntWritable,DoubleWritable,IntWritable,Text>{
	double sum=0;
	double avg=0;
	public void reduce(IntWritable inpk,Iterable<DoubleWritable> inpv,Context c) throws IOException, InterruptedException{
	    int count=0;
	    
	    
		for(DoubleWritable x:inpv){
			
			sum+=x.get();
		
			
			count=count+1;
			
			
			}
	//	avg=sum/count;
		c.write(inpk, new Text("----  "+sum));
	}
}