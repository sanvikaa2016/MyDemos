
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class reducer5 extends Reducer<IntWritable,Text,IntWritable,Text>{

	public void reduce(IntWritable inpk,Text inpv,Context c) throws IOException, InterruptedException
	{	
		c.write(inpk,inpv);
	}
}