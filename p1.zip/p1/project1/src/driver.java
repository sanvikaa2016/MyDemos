

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class driver {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
Scanner src = new Scanner(System.in);
try{
		System.out.println("Enter your choice:--");
		System.out.println("1-->Find userid whose purchase amount should be greater than given value");
		System.out.println("2-->To Count all transaction between the given amount");
		System.out.println("3-->Calculate sum and count of transaction of each user id");
		System.out.println("4-->Calculate total sales amt for each Month");
		System.out.println("5-->To place total sales of each month in different files");
		int choice=src.nextInt();

		switch(choice){
		case 1:
		Configuration conf1 = new Configuration();
		System.out.println("Enter the minimum value----");
		int amt = src.nextInt();
		conf1.setInt("Amount", amt);
	if(amt>=1){
		Job j1 = new Job(conf1, "Output");
		FileSystem hdfs1 = FileSystem.get(conf1);
		j1.setJarByClass(driver.class);
		j1.setMapperClass(mapper1.class);
		j1.setNumReduceTasks(0);
		j1.setMapOutputKeyClass(Text.class);
		j1.setMapOutputValueClass(DoubleWritable.class);
		j1.setInputFormatClass(inputformat.class);
		
		FileInputFormat.addInputPath(j1, new Path(args[0]));
		FileOutputFormat.setOutputPath(j1, new Path (args[1]));
		
		Path newpath1 = new Path(args[1]);
		if(hdfs1.exists(newpath1)){
			hdfs1.delete(newpath1,true);
		}
		Path localfilepath1 = new Path("/home/hduser/InputFormat_Trans1");
		if(j1.waitForCompletion(true)){
			hdfs1.copyToLocalFile(newpath1, localfilepath1);
		}
			
		
		System.exit(j1.waitForCompletion(true)?0:1);
	}
	else
	{
		System.out.println("Pls type minumum value from 1");
	}
		break;
		case 2:
			Configuration conf2 = new Configuration();
			System.out.println("Enter the Min amount");
			int lamt = src.nextInt();
			System.out.println("Enter the Max amount");
			int uamt = src.nextInt();
			if(uamt>=lamt){
			conf2.setInt("Lower", lamt);
			conf2.setInt("Upper", uamt);
			Job j2 = new Job(conf2, "Output");
			FileSystem hdfs2 = FileSystem.get(conf2);
			j2.setJarByClass(driver.class);
			j2.setMapperClass(mapper2.class);
			j2.setReducerClass(reducer2.class);
			j2.setNumReduceTasks(1);
			j2.setMapOutputKeyClass(Text.class);
			j2.setMapOutputValueClass(IntWritable.class);
			j2.setInputFormatClass(inputformat.class);
			
			FileInputFormat.addInputPath(j2, new Path(args[0]));
			FileOutputFormat.setOutputPath(j2, new Path (args[1]));
			
			Path newpath2 = new Path(args[1]);
			if(hdfs2.exists(newpath2)){
				hdfs2.delete(newpath2,true);
			}
			Path localfilepath2 = new Path("/home/hduser/InputFormat_Trans2");
			if(j2.waitForCompletion(true)){
				hdfs2.copyToLocalFile(newpath2, localfilepath2);
			}
			
			System.exit(j2.waitForCompletion(true)?0:1);}
			else
			{
				System.out.println("Max amount should be greater than minimum anount");
			}
			break;
		case 3:
			Configuration conf3 = new Configuration();
			System.out.println("Enter the user id");
			int uid = src.nextInt();
			if((uid>=4000000)&&(uid<=4999999)){
			conf3.setInt("User id", uid);
			Job j3 = new Job(conf3, "Output");
			FileSystem hdfs3 = FileSystem.get(conf3);
			j3.setJarByClass(driver.class);
			j3.setMapperClass(mapper3.class);
			j3.setReducerClass(reducer3.class);
			j3.setNumReduceTasks(1);
			j3.setMapOutputKeyClass(Text.class);
			j3.setMapOutputValueClass(DoubleWritable.class);
			j3.setInputFormatClass(inputformat.class);
			
			FileInputFormat.addInputPath(j3, new Path(args[0]));
			FileOutputFormat.setOutputPath(j3, new Path (args[1]));
			
			Path newpath3 = new Path(args[1]);
			if(hdfs3.exists(newpath3)){
				hdfs3.delete(newpath3,true);
			}
			Path localfilepath3 = new Path("/home/hduser/InputFormat_Trans3");
			if(j3.waitForCompletion(true)){
				hdfs3.copyToLocalFile(newpath3, localfilepath3);
			}
			
			System.exit(j3.waitForCompletion(true)?0:1);}
			else
			{
				System.out.println("userid is not valid");
			}
			break;
		case 4:			
			Configuration conf4 = new Configuration();
					Job j4 = new Job(conf4, "Output");
			FileSystem hdfs4 = FileSystem.get(conf4);
			j4.setJarByClass(driver.class);
	     	j4.setMapperClass(mapper4.class);
	     	j4.setMapOutputKeyClass(IntWritable.class);
	     	j4.setMapOutputValueClass(DoubleWritable.class);
	     	FileInputFormat.addInputPath(j4, new Path(args[0]));
	     	FileOutputFormat.setOutputPath(j4, new Path(args[1]));
	     	System.exit(j4.waitForCompletion(true)?0:1);
		
	     	break;
	     	
		case 5:
			Configuration c = new Configuration();
			Job j=new Job(c,"first program");
			j.setJarByClass(driver.class);
			j.setMapperClass(mapper5.class);
			j.setReducerClass(reducer5.class);
			j.setPartitionerClass(part5.class);
			j.setNumReduceTasks(12);
			j.setMapOutputKeyClass(IntWritable.class);
			j.setMapOutputValueClass(Text.class);
			FileInputFormat.addInputPath(j, new Path(args[0]));
			FileOutputFormat.setOutputPath(j, new Path(args[1]));
			System.exit(j.waitForCompletion(true)?0:1);
	     	
			default:
				System.out.println("Pls enter choice between 1 to 5");
				break;
	}
	}
		catch(InputMismatchException e)
		{
			System.out.println("pls enter whole number");
		}
}}
